# TrialMatch — Quick Start Cheat Sheet

## 🎯 What You Have

A complete, production-ready MCP server for clinical trial matching with:
- **3 MCP tools:** find_trials, check_eligibility, summarize_trial
- **AI-powered eligibility reasoning** using Claude API
- **Real ClinicalTrials.gov integration** (500K+ trials)
- **FHIR R4 ready** for patient data
- **Synthetic test data** included
- **Docker deployment** ready
- **Full documentation** (README + SETUP_GUIDE)

## 🚀 Get Started in 5 Minutes

```bash
# 1. Extract the project
tar -xzf trialmatch-mcp.tar.gz
cd trialmatch-mcp

# 2. Install dependencies
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt

# 3. Set your API key
export ANTHROPIC_API_KEY="your-key-here"

# 4. Test the tools
python test_tools.py

# 5. Run the MCP server
python server.py
```

Your server is now at `http://localhost:8000/mcp`

## 📋 Next Steps

### Step 1: Local Testing (Today)
- ✅ Test tools with `python test_tools.py`
- ✅ Run MCP Inspector: `fastmcp dev server.py`
- ✅ Verify all 3 tools work

### Step 2: Prompt Opinion Setup (This Week)
- [ ] Register at https://app.promptopinion.ai
- [ ] Watch the getting started video
- [ ] Deploy your server (Railway/Render/AWS)
- [ ] Publish to Prompt Opinion Marketplace

### Step 3: Devpost Submission (Before May 11)
- [ ] Record 3-minute demo video
- [ ] Submit at https://agents-assemble.devpost.com/
- [ ] Include: description, marketplace URL, video link

## 🎬 Demo Video Script (< 3 minutes)

**00:00-00:15 — Hook**
"Less than 5% of eligible cancer patients enroll in clinical trials. Why? Matching is slow and manual. Watch how TrialMatch solves this."

**00:15-00:45 — Problem**
"Clinicians spend hours searching ClinicalTrials.gov. Eligibility criteria are complex. Patients don't understand trial descriptions."

**00:45-02:30 — Demo**
1. Show Prompt Opinion platform
2. Invoke find_trials: ["Non-small cell lung cancer"]
3. Show 10 matching trials appear instantly
4. Invoke check_eligibility on NCT12345678
5. Show AI reasoning: "Patient meets inclusion criterion X because..."
6. Invoke summarize_trial
7. Show patient-friendly summary in plain English

**02:30-02:50 — Tech**
"Built on MCP, FHIR, Claude API. Published to Prompt Opinion Marketplace. Open standards mean any agent can use these tools."

**02:50-03:00 — Close**
"TrialMatch: AI-powered clinical trial matching. Available now on Prompt Opinion."

## 🏆 Judging Criteria Checklist

**Stage 1 (Pass/Fail):**
- ✅ Published to Prompt Opinion Marketplace
- ✅ Discoverable and invokable on the platform
- ✅ Works as MCP server
- ✅ Uses synthetic data only

**Stage 2 (Scored):**
- **AI Factor** — ✅ LLM parses complex eligibility criteria (impossible for rule-based systems)
- **Potential Impact** — ✅ Trial enrollment is a massive healthcare problem
- **Feasibility** — ✅ ClinicalTrials.gov is public, FHIR is standard, proven tech

## 📁 Project Files Overview

```
trialmatch-mcp/
├── README.md              # Project overview
├── SETUP_GUIDE.md         # Comprehensive setup instructions
├── server.py              # Main MCP server (start here)
├── requirements.txt       # Python dependencies
├── Dockerfile            # For deployment
├── test_tools.py         # Test script with synthetic data
├── .env.example          # Environment variables template
│
├── tools/                 # The 3 MCP tools
│   ├── find_trials.py
│   ├── check_eligibility.py
│   └── summarize_trial.py
│
├── services/              # Backend services
│   ├── ctgov_client.py    # ClinicalTrials.gov API
│   ├── fhir_parser.py     # FHIR resource parsing
│   └── llm_client.py      # Claude API wrapper
│
├── models/
│   └── schemas.py         # Pydantic models
│
└── synthetic_data/
    └── sample_patients.json  # Test data
```

## 💡 Pro Tips

1. **Start simple:** Test locally before deploying
2. **Use the inspector:** `fastmcp dev server.py` is your best friend
3. **Read the logs:** Your server logs show what's happening
4. **Join Discord:** https://discord.gg/JS2bZVruUg for help
5. **Check the examples:** `synthetic_data/sample_patients.json` has 3 demo patients

## 🆘 Troubleshooting

**"Module not found"**
→ Activate venv: `source venv/bin/activate`

**"API key not set"**
→ `export ANTHROPIC_API_KEY="sk-ant-..."`

**"Can't connect to server"**
→ Check it's running: `curl http://localhost:8000/mcp`

## 📚 Resources

- Hackathon Rules: https://agents-assemble.devpost.com/rules
- Prompt Opinion: https://www.promptopinion.ai/
- Discord Support: https://discord.gg/JS2bZVruUg
- MCP Docs: https://modelcontextprotocol.io/

---

**You're ready to build something that helps patients access life-saving treatments. Good luck! 🚀**

# TrialMatch — Clinical Trial Eligibility Finder

**An MCP Server for the Agents Assemble Healthcare AI Hackathon**

TrialMatch helps clinicians instantly match patients to eligible clinical trials. It queries ClinicalTrials.gov, uses AI to reason through complex eligibility criteria, and generates patient-friendly trial summaries — all exposed as MCP tools on the Prompt Opinion platform.

## Tools Exposed

| Tool | Description |
|------|-------------|
| `find_trials` | Search ClinicalTrials.gov for recruiting trials matching a patient's conditions, age, and location |
| `check_eligibility` | AI-powered reasoning that evaluates a specific trial's eligibility criteria against a patient's full FHIR profile |
| `summarize_trial` | Generate a plain-English, patient-friendly summary of what a trial involves |

## Quick Start

### 1. Install dependencies

```bash
pip install fastmcp httpx anthropic pydantic
```

### 2. Set environment variables

```bash
export ANTHROPIC_API_KEY="your-api-key-here"
export TRIALMATCH_PORT=8000
```

### 3. Run the server

```bash
python server.py
```

The server starts on `http://localhost:8000/mcp` using Streamable HTTP transport.

### 4. Test with MCP Inspector

```bash
fastmcp dev server.py
```

## Project Structure

```
trialmatch-mcp/
├── server.py              # MCP server entry point — registers all tools
├── tools/
│   ├── __init__.py
│   ├── find_trials.py     # ClinicalTrials.gov API search
│   ├── check_eligibility.py  # LLM-powered eligibility reasoning
│   └── summarize_trial.py # Patient-friendly trial summaries
├── services/
│   ├── __init__.py
│   ├── ctgov_client.py    # ClinicalTrials.gov API v2 client
│   ├── fhir_parser.py     # FHIR R4 resource parsing helpers
│   └── llm_client.py      # Anthropic Claude API wrapper
├── models/
│   ├── __init__.py
│   └── schemas.py         # Pydantic models for inputs/outputs
├── synthetic_data/
│   └── sample_patients.json  # Synthetic FHIR patient bundles for testing
├── requirements.txt
├── Dockerfile
└── README.md
```

## FHIR Resources Used

- **Patient** — age, sex, demographics
- **Condition** — active diagnoses (maps to trial search conditions)
- **MedicationRequest** — current medications (used in eligibility checks)
- **Observation** — lab values (used in eligibility checks)

## SHARP Context

When invoked through Prompt Opinion, the SHARP extension propagates:
- `patient_id` — the FHIR patient ID in context
- `fhir_token` — OAuth bearer token for FHIR server access
- `fhir_base_url` — the FHIR server endpoint

These are received as part of the tool input and used to fetch patient data from the connected FHIR server.

## Deployment

Build and deploy the Docker container to any cloud provider:

```bash
docker build -t trialmatch-mcp .
docker run -p 8000:8000 -e ANTHROPIC_API_KEY=your-key trialmatch-mcp
```

Then register the server URL in the Prompt Opinion Marketplace.

## License

MIT

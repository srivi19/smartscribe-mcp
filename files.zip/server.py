"""
TrialMatch MCP Server
=====================
Clinical Trial Eligibility Finder for the Prompt Opinion platform.

Exposes 3 tools:
  - find_trials:       Search for recruiting trials by condition
  - check_eligibility: AI-powered eligibility reasoning
  - summarize_trial:   Patient-friendly trial summaries

Run:
  python server.py

Test with MCP Inspector:
  fastmcp dev server.py
"""

import os
import json
from fastmcp import FastMCP

from tools.find_trials import find_trials as _find_trials
from tools.check_eligibility import check_eligibility as _check_eligibility
from tools.summarize_trial import summarize_trial as _summarize_trial

# ──────────────────────────────────────────────
# Server setup
# ──────────────────────────────────────────────

mcp = FastMCP(
    "TrialMatch",
    description=(
        "Clinical Trial Eligibility Finder — search ClinicalTrials.gov, "
        "evaluate patient eligibility with AI reasoning, and generate "
        "patient-friendly trial summaries. Built for the Prompt Opinion "
        "healthcare AI platform."
    ),
)


# ──────────────────────────────────────────────
# Tool 1: find_trials
# ──────────────────────────────────────────────

@mcp.tool()
async def find_trials(
    conditions: list[str],
    age: int | None = None,
    sex: str | None = None,
    location: str | None = None,
    max_results: int = 10,
) -> str:
    """
    Search ClinicalTrials.gov for actively recruiting clinical trials
    that match the given patient conditions.

    Use this tool when a clinician wants to find clinical trials for a
    patient based on their diagnoses. Provide the patient's conditions
    as a list of strings (e.g. ["Non-small cell lung cancer", "EGFR mutation"]).

    Optionally filter by age, sex, and geographic location.

    Returns a list of matching trials with NCT IDs, titles, phases,
    and brief summaries.

    Args:
        conditions: List of patient diagnoses to search for.
        age: Patient age in years for eligibility filtering.
        sex: Patient sex — "male", "female", or "all".
        location: Geographic filter (e.g. "Tennessee, US").
        max_results: Max trials to return (default 10, max 20).
    """
    result = await _find_trials(
        conditions=conditions,
        age=age,
        sex=sex,
        location=location,
        max_results=max_results,
    )
    return json.dumps(result, indent=2)


# ──────────────────────────────────────────────
# Tool 2: check_eligibility
# ──────────────────────────────────────────────

@mcp.tool()
async def check_eligibility(
    nct_id: str,
    patient_conditions: list[str],
    patient_medications: list[str],
    patient_age: int,
    patient_sex: str,
    patient_lab_results: list[dict] | None = None,
) -> str:
    """
    Evaluate whether a specific patient meets the eligibility criteria
    of a clinical trial using AI-powered reasoning.

    This tool fetches the trial's full eligibility criteria from
    ClinicalTrials.gov and uses an LLM to reason through each
    inclusion and exclusion criterion against the patient's profile.

    Returns a detailed assessment with per-criterion evaluation,
    overall verdict (eligible/ineligible/uncertain), confidence level,
    and a list of missing data that would help clarify eligibility.

    IMPORTANT: This tool uses SYNTHETIC data only. It is an assistive
    tool and does NOT replace clinical judgment.

    Args:
        nct_id: ClinicalTrials.gov NCT ID (e.g. "NCT05580562").
        patient_conditions: List of active diagnoses (e.g. ["Type 2 Diabetes", "Hypertension"]).
        patient_medications: List of current medications (e.g. ["Metformin 500mg", "Lisinopril 10mg"]).
        patient_age: Patient age in years.
        patient_sex: "male" or "female".
        patient_lab_results: Optional list of recent labs, each a dict with keys: name, value, unit.
    """
    patient_profile = {
        "conditions": patient_conditions,
        "medications": patient_medications,
        "age": patient_age,
        "sex": patient_sex,
        "lab_results": patient_lab_results or [],
    }

    result = await _check_eligibility(
        nct_id=nct_id,
        patient_profile=patient_profile,
    )
    return json.dumps(result, indent=2)


# ──────────────────────────────────────────────
# Tool 3: summarize_trial
# ──────────────────────────────────────────────

@mcp.tool()
async def summarize_trial(
    nct_id: str,
    reading_level: str = "patient",
) -> str:
    """
    Generate a clear, readable summary of a clinical trial.

    Use this tool when a clinician wants to explain a trial to a
    patient, or when anyone needs a quick overview of what a study
    involves. The summary covers: what the study is about, what
    participants will experience, who can join, duration, potential
    benefits and risks, and contact information.

    Args:
        nct_id: ClinicalTrials.gov NCT ID (e.g. "NCT05580562").
        reading_level: "patient" for plain English (default) or
                       "clinician" for technical language.
    """
    result = await _summarize_trial(
        nct_id=nct_id,
        reading_level=reading_level,
    )
    return json.dumps(result, indent=2)


# ──────────────────────────────────────────────
# Entry point
# ──────────────────────────────────────────────

if __name__ == "__main__":
    port = int(os.environ.get("TRIALMATCH_PORT", 8000))
    print(f"Starting TrialMatch MCP Server on port {port}...")
    print(f"MCP endpoint: http://localhost:{port}/mcp")
    print(f"Tools: find_trials, check_eligibility, summarize_trial")
    mcp.run(transport="streamable-http", port=port)

# TrialMatch Setup & Deployment Guide

## Phase 1: Local Development & Testing

### 1. Prerequisites

- Python 3.10 or higher
- An Anthropic API key (get one at https://console.anthropic.com/)
- Git (for version control)

### 2. Initial Setup

```bash
# Clone or navigate to the project directory
cd trialmatch-mcp

# Create a virtual environment
python -m venv venv

# Activate it
# On macOS/Linux:
source venv/bin/activate
# On Windows:
venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Create your .env file
cp .env.example .env

# Edit .env and add your Anthropic API key
# nano .env  (or use your preferred editor)
```

### 3. Test the Tools Directly

Before running the MCP server, test that the tools work:

```bash
# Make sure your ANTHROPIC_API_KEY is set
export ANTHROPIC_API_KEY="your-key-here"

# Run the test script
python test_tools.py
```

This will:
- Search ClinicalTrials.gov for lung cancer trials
- Evaluate a patient's eligibility using AI
- Generate a patient-friendly summary

Expected output: You should see trial results, eligibility reasoning, and a summary.

### 4. Run the MCP Server Locally

```bash
# Start the server
python server.py
```

You should see:
```
Starting TrialMatch MCP Server on port 8000...
MCP endpoint: http://localhost:8000/mcp
Tools: find_trials, check_eligibility, summarize_trial
```

The server is now running and ready to accept MCP tool calls.

### 5. Test with MCP Inspector

The MCP Inspector is a web UI for testing your server:

```bash
# Install the FastMCP CLI tools if you haven't
pip install 'fastmcp[cli]'

# Run the inspector
fastmcp dev server.py
```

This opens a browser where you can:
- See all your tools listed
- Click on a tool to test it
- Enter parameters and run it
- View the JSON response

**Example test:**
1. Click on `find_trials`
2. Enter conditions: `["Type 2 Diabetes"]`
3. Enter age: `55`
4. Click "Run Tool"
5. You should see matching trials from ClinicalTrials.gov

---

## Phase 2: Prompt Opinion Integration

### 1. Register at Prompt Opinion

1. Go to https://app.promptopinion.ai
2. Create a free account
3. Complete the onboarding

### 2. Watch the Getting Started Video

https://youtu.be/Qvs_QK4meHc

This shows you how to:
- Navigate the Prompt Opinion platform
- Understand MCP server registration
- Publish your server to the marketplace

### 3. Deploy Your Server

Your MCP server needs to be publicly accessible for Prompt Opinion to call it. Options:

**Option A: Quick Deploy with Railway.app (easiest)**

```bash
# Install Railway CLI
npm install -g @railway/cli

# Login
railway login

# Initialize and deploy
railway init
railway up
```

Railway will:
- Build your Docker container
- Deploy it to a public URL
- Give you a URL like `https://trialmatch-production-xxxx.up.railway.app`

**Option B: Docker on Any Cloud Provider**

```bash
# Build the image
docker build -t trialmatch-mcp .

# Test locally
docker run -p 8000:8000 -e ANTHROPIC_API_KEY=your-key trialmatch-mcp

# Push to your cloud provider (AWS, GCP, Azure, etc.)
# Each provider has different steps — consult their docs
```

### 4. Register Your Server in Prompt Opinion

Once deployed, you need to register your MCP server URL in the Prompt Opinion marketplace:

1. In Prompt Opinion, go to "Marketplace" or "Developer Tools"
2. Click "Register MCP Server" or "Add New Tool"
3. Enter your server URL: `https://your-server.com/mcp`
4. Add metadata:
   - Name: TrialMatch
   - Description: Clinical Trial Eligibility Finder
   - Tags: clinical trials, eligibility, patient matching
5. Test the connection (Prompt Opinion will ping your `/mcp` endpoint)
6. Publish to the marketplace

### 5. Verify Marketplace Publication

After publishing:
- Your tools should be discoverable in the Prompt Opinion workspace
- Other agents on the platform can invoke your tools
- The SHARP context (patient ID, FHIR token) will be automatically propagated

**Test it:**
1. Open a Prompt Opinion workspace
2. Try invoking one of your tools via an agent
3. Check the logs on your server to see the requests coming in

---

## Phase 3: Devpost Submission

### 1. Create Your Demo Video (< 3 minutes)

Record a screen capture showing:
1. **Opening** (5 sec): "TrialMatch — Clinical Trial Eligibility Finder"
2. **Problem** (15 sec): "Only 5% of eligible cancer patients enroll in trials because matching is manual and slow."
3. **Solution** (20 sec): "TrialMatch uses AI to instantly match patients to trials and explain eligibility in plain English."
4. **Demo** (90 sec):
   - Show the Prompt Opinion platform
   - Invoke `find_trials` with a patient's conditions
   - Show the list of matching trials
   - Invoke `check_eligibility` on one trial
   - Show the AI's reasoning ("Patient meets inclusion criteria X because...")
   - Invoke `summarize_trial` and show the patient-friendly summary
5. **Architecture** (30 sec): Show your architecture diagram (from earlier) — MCP, FHIR, ClinicalTrials.gov API, LLM
6. **Closing** (10 sec): "Built on open standards. Published to Prompt Opinion marketplace. Ready for production."

**Tools for recording:**
- macOS: QuickTime, or use Loom
- Windows: Xbox Game Bar, OBS, or Loom
- Linux: SimpleScreenRecorder, OBS

Upload to YouTube or Vimeo (unlisted is fine).

### 2. Prepare Your Devpost Submission

Go to https://agents-assemble.devpost.com/ and submit:

**Project Description:**

```
TrialMatch is an MCP server that helps clinicians instantly match patients to clinical trials using AI-powered eligibility reasoning.

**The Problem:**
Less than 5% of eligible cancer patients enroll in clinical trials. Manual trial matching is time-consuming (clinicians spend hours searching ClinicalTrials.gov) and eligibility criteria are written in complex medical jargon that's hard to parse.

**The Solution:**
TrialMatch exposes three MCP tools on the Prompt Opinion platform:
• find_trials — Searches 500,000+ trials on ClinicalTrials.gov by condition, age, location
• check_eligibility — Uses an LLM to reason through complex eligibility criteria line-by-line
• summarize_trial — Generates patient-friendly summaries in plain English

**Tech Stack:**
• MCP: Anthropic's Model Context Protocol for tool discovery
• FHIR R4: Patient data in standardized healthcare format
• ClinicalTrials.gov API v2: 500K+ trial database
• Claude API: AI-powered eligibility reasoning
• Python + FastMCP: Server implementation
• Deployed on Railway.app, published to Prompt Opinion Marketplace

**Why it matters:**
Eligibility criteria are inherently non-deterministic — they're written in natural language with edge cases, exceptions, and clinical judgment. Rule-based systems fail here. LLMs excel at parsing ambiguous text and reasoning through "patient has X, criterion requires Y — does X satisfy Y?" questions.

This is the AI Factor: GenAI does something traditional software fundamentally cannot.
```

**Required Fields:**
- **Text description:** (the above)
- **Marketplace URL:** https://app.promptopinion.ai/marketplace/trialmatch (or your actual marketplace link)
- **Demo video:** Your YouTube/Vimeo link
- **GitHub repo:** (optional but recommended) Your public GitHub repo with the code

### 3. Double-Check Stage 1 Requirements (Pass/Fail)

Before submitting, verify:
- ✅ Project is published to Prompt Opinion Marketplace
- ✅ It's discoverable and invokable within the platform
- ✅ It works as an MCP server (tools are exposed correctly)
- ✅ It uses only synthetic/de-identified data
- ✅ Video shows it functioning within Prompt Opinion

**If any of these fail, you won't pass Stage 1 judging.**

---

## Phase 4: Post-Submission Polish

While waiting for judging, improve your project:

### Add More Tools (Optional Enhancements)

Ideas:
- `compare_trials` — Side-by-side comparison of 2-3 trials
- `explain_criterion` — Plain-English explanation of a specific eligibility rule
- `find_nearby_sites` — Geocode locations and find closest trial sites

### Improve Eligibility Reasoning

Fine-tune your prompts:
- Add examples of tricky criteria (e.g., "ECOG performance status ≤1")
- Handle date-based criteria ("diagnosed within last 6 months")
- Flag criteria that need clinical judgment

### Add Logging & Monitoring

```python
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@mcp.tool()
async def find_trials(...):
    logger.info(f"find_trials called with conditions={conditions}")
    # ...
```

This helps you debug issues when the judges test your server.

---

## Troubleshooting

### "Module not found" errors

Make sure you're in the virtual environment:
```bash
source venv/bin/activate  # or venv\Scripts\activate on Windows
pip install -r requirements.txt
```

### "ANTHROPIC_API_KEY not set"

```bash
export ANTHROPIC_API_KEY="sk-ant-..."
```

Or add it to your `.env` file and load it:
```python
from dotenv import load_dotenv
load_dotenv()
```

### ClinicalTrials.gov API is slow

The API can be slow (10-30 seconds for searches). This is normal. Consider:
- Reducing `max_results`
- Caching results
- Adding a timeout warning in your tool docstring

### MCP Inspector won't connect

Make sure the server is running on the correct port:
```bash
ps aux | grep python  # Check if server.py is running
curl http://localhost:8000/mcp  # Test the endpoint
```

---

## Resources

- **Prompt Opinion Docs:** https://www.promptopinion.ai/videos
- **MCP Spec:** https://modelcontextprotocol.io/
- **ClinicalTrials.gov API:** https://clinicaltrials.gov/data-api/api
- **FHIR R4 Spec:** https://hl7.org/fhir/R4/
- **FastMCP Docs:** https://github.com/jlowin/fastmcp
- **Hackathon Discord:** https://discord.gg/JS2bZVruUg

---

Good luck! You're building something that could genuinely help patients access life-saving treatments. 🚀
